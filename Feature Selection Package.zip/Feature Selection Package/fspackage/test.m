addpath('classifiers');
clear
load testData
trainX=data(1:12,2:3);
trainY=data(1:12,5);
testX=data(13:18,2:3);
testY=data(13:18,5);
opt=1;
result=knnPrediction(trainX,trainY,testX,testY,opt);