function [ res ] = CVBayes( trainData,testData )
[m1,n1]=size(trainData);
[m2,n2]=size(trainData);

    train_data=trainData(:,1:n1-1);
    train_target=trainData(:,n1);
    test_data=testData(:,1:n2-1);
    test_target=testData(:,n2);
    result=Bayes_CV_estimate(train_data,train_target,test_data,test_target);

res=result ;
end

