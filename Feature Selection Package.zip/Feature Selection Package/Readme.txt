What to do once you've installed Feature Selection Package:

1.   Open MATLAB
2.   Use MATLAB's 'cd' function to navigate to the folder you
       installed Feature Selection Package into.
3.   Run the load_fspackage function with the command: 'load_fspackage'
4.   Select all of the commands you have run in this session, right click,
       and select 'Create Shortcut'. This will give you a shortcut which
       you can use to open Feature Selection Package at your choosing.